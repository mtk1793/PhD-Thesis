# Restoring the original CAPSM archive contents

1. Download **all 17 numbered ZIP parts** from the delivery folder, preserving their exact names.
2. Place them together in an `archive_parts` folder.
3. Run `python RESTORE_ARCHIVES.py archive_parts restored`.
4. Check original file SHA-256 values against `SPLIT_MANIFEST.csv`.
5. An independent restoration test verified every extracted file against the supplied `CAPSM_v27_FINAL_RESEARCH_AND_THESIS.zip`.

**Important:** A `*.zip.part01` entry is a fragment of a historical ZIP; do not open it as a complete ZIP. The restore script joins fragments by their numeric suffix. Do not rename the numbered parts.
