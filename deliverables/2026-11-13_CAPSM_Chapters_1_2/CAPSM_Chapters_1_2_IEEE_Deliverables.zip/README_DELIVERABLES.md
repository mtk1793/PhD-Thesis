# CAPSM Chapters 1–2 — IEEE-style research-writing package

**Source:** Uploaded CAPSM_PhD_Thesis_FINAL.docx and CAPSM_v27_FINAL_RESEARCH_AND_THESIS.zip (13 November 2026).

**Chapter 1:** Introduction — approximately 2,476 words. **Chapter 2:** Literature Review and Theoretical Background — approximately 5,224 words. 

**Format:** US Letter, Times New Roman 10 pt, one column (two-column layout was not explicitly requested), numbered headings, [n] citation style with chapter-local numbering, and reference lists at the end of each chapter.

**Content:** Two original AI-authored conceptual diagrams (SVG and PNG), Fig. 1 and Fig. 2; two comparison tables, Table I and Table II; a 15-entry Zotero-importable BibTeX subset; and a citation verification ledger.

**Evidence boundaries:** The original supplied thesis reports no established advantage of its tested CNN–LSTM, quantum-inspired search, or Arbiter over the specified classical controls; MPC is the positive benchmark. These conclusions remain intact. Static AC results do not establish RMS or HIL security. The selected references are from the source's Crossref-audited corpus, with six selectively cross-checked against publisher or scholarly pages in this session; other entries require independent review before submission. Review the source-bibliography audit: its summary reports 188 verified entries despite other source prose claiming 200.

**Manuscript:** `CAPSM_Chapters_1_2_IEEE_Style.docx`, PDF preview produced by LibreOffice for layout QA.

**Reference file:** `CAPSM_Chapters_1_2_Zotero.bib`.

**Archive splitting:** The full 203.25 MiB compressed source archive is preserved by the 17 numbered ZIP archives in `archive_parts/`. Extract all parts into one directory using `RESTORE_ARCHIVES.py`, which reassembles historical nested ZIP fragments. The restoration was verified byte-for-byte for every original file. `SPLIT_MANIFEST.csv` records each original file hash; `PARTS_DOWNLOAD_LIST.csv` records each volume hash.

**Repository:** `https://github.com/mtk1793/PhD-Thesis`, `master`. GitHub's connector accepts UTF-8 files but not uploaded binary paths; larger binary artifacts are distributed via a Drive folder and referenced by repository metadata. The separate Git operation report records what was actually committed.
