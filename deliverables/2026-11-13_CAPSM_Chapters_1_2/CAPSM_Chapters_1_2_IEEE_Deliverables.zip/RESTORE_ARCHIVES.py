#!/usr/bin/env python3
"""Extract every numbered logical part and rejoin exact historical ZIP payloads."""
import sys,zipfile,pathlib,hashlib,collections,csv
parts=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'archive_parts')
target=pathlib.Path(sys.argv[2] if len(sys.argv)>2 else 'RESTORED_CAPSM')
target.mkdir(parents=True,exist_ok=True)
for a in sorted(parts.glob('*.zip')):
  with zipfile.ZipFile(a) as z:
    if z.testzip() is not None:raise ValueError('Corrupt '+a.name)
    for info in z.infolist():
      path=pathlib.PurePosixPath(info.filename)
      if '..' in path.parts or path.is_absolute():raise ValueError('Unsafe member '+str(path))
      dest=target.joinpath(*path.parts);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(info.filename))
for fst in target.rglob('*.part01'):
  base=fst.with_name(fst.name[:-7]);chunks=[];n=1
  while (base.with_name(base.name+'.part'+str(n).zfill(2))).exists():
    chunks.append(base.with_name(base.name+'.part'+str(n).zfill(2)));n+=1
  with open(base,'wb') as out:
    for c in chunks:out.write(c.read_bytes())
  for c in chunks:c.unlink()
print('Restored',target)
